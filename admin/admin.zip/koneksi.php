<?php
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "azindorayap";
$connect    = mysqli_connect($host, $user, $password, $database);
?>