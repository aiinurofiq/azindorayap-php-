<?php
session_start();
unset($_SESSION['username']);


?>
<meta http-equiv="refresh" content="1;URL=index.php">